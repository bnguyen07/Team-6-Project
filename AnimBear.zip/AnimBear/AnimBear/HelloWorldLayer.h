//
//  HelloWorldLayer.h
//  AnimBear
//
//  Created by Ray Wenderlich on 3/12/13.
//  Copyright Razeware LLC 2013. All rights reserved.
//

#import "cocos2d.h"

@interface HelloWorldLayer : CCLayer
{
}

+(CCScene *) scene;

@end
