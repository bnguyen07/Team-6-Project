//
//  main.m
//  AnimBear
//
//  Created by Ray Wenderlich on 3/12/13.
//  Copyright Razeware LLC 2013. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, @"AppController");
        return retVal;
    }
}
